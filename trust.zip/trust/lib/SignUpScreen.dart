import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';


class SignUpScreen extends StatelessWidget 
{
  @override
  Widget build(BuildContext context) 
  {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Text('first time splash screen')
    );
  }
}
